Hello this is a repository for making a ray-tracing engine using Solar2d(formerly known as CoronaSDK)

this project uses the built in glsl shader support offered and has no good reason to exist other than showing off to my computer science teacher

feel free to contribute if you feel like it :)
